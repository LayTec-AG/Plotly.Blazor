self.assetsManifest = {
  "version": "RtaCqyrR",
  "assets": [
    {
      "hash": "sha256-BGK1YGP/P2sMMyzSZJSk1J959tqWV7LsQfMUWQjJF7M=",
      "url": "2011_february_aa_flight_paths.csv"
    },
    {
      "hash": "sha256-vZ54Fl+/9QN4fawzVizuo6/ZWt1LAxTtk5/yYkjT8x0=",
      "url": "Plotly.Blazor.Examples.styles.css"
    },
    {
      "hash": "sha256-4U4VjN2yYuSv0hJWjfrPs9iSFsZ5W0YiXR4AQnFkLGQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-eE4vNh0w0D1v6t34qSz3NxH2sZdko1JF7vFMe/XhHTY=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-TQCgpSIKzI2pq61mDxZfI3hZ5xI1+WQ5tL19KrbNv3k=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-BYL2EScwS+NAvt/rjWDFCbwlOZrj89v0jvqJtlTFZb8=",
      "url": "_content/Plotly.Blazor/plotly-3.5.0.min.js"
    },
    {
      "hash": "sha256-au6OANfoslCboDDNGDSbwuYrw4ajfIzGma4RYGDyldM=",
      "url": "_content/Plotly.Blazor/plotly-basic-3.5.0.min.js"
    },
    {
      "hash": "sha256-Jy8hpu2KbtNrGhmn4as7OG6Uo+9LhfaGQ8GfH/LOPd0=",
      "url": "_content/Plotly.Blazor/plotly-interop-7.1.0.js"
    },
    {
      "hash": "sha256-XOjbt367aR5lsmPpWF5IRw2ARa7VZjseRHvyyDpSHrM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.0fglywox5r.wasm"
    },
    {
      "hash": "sha256-bgEUftvsbHlavz66DaxxZEHUtVbcb2qApWjkKsT8gXg=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.q9tppmt4x6.wasm"
    },
    {
      "hash": "sha256-CnzS8yS2mJyY6ZlL4aYDaQyuKH451hd1aV8gpj2qhoI=",
      "url": "_framework/Microsoft.AspNetCore.Components.eimo4i7uh8.wasm"
    },
    {
      "hash": "sha256-d3GcRUkr4YTaaPDykUyaP924sHvu24hlRUD/2juvncw=",
      "url": "_framework/Microsoft.Extensions.Configuration.5p4nbzgbzx.wasm"
    },
    {
      "hash": "sha256-hU9d1ZVqcgX4x+k4IT/Qy9WaoY0w17UiLFuPUusBrZU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.7x5uj9wykr.wasm"
    },
    {
      "hash": "sha256-bQ5MSDYNor9dBuG+8uV0WgBhsmteqeux7mvEXXJ0S3U=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.pdkpfzous1.wasm"
    },
    {
      "hash": "sha256-DLFAGbpOqHqmV5LUBh69cfvGiwvBrNU4cerrg+eZBhg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.k0m6a8f15o.wasm"
    },
    {
      "hash": "sha256-Q+epjbdG79n9rdlxw2Vvt1iW7O1Vr363hRPCin+irmY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.lm1u9j6ipz.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-eSRbrFbUsBLKfFvEij3A4RiP6g+NL7GiITz0282Ahq8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.rz45v5kdbo.wasm"
    },
    {
      "hash": "sha256-Gzcnf/8ZD9wxU7EP67LorJAQcQUtPpLyTGH1rR8BP24=",
      "url": "_framework/Microsoft.Extensions.Logging.b4cnq0cyz4.wasm"
    },
    {
      "hash": "sha256-kfWmOTLC1lT23+D0Z/Nw3BGAqPdD28//j/wiJM6lldI=",
      "url": "_framework/Microsoft.Extensions.Options.jjb8yf2weu.wasm"
    },
    {
      "hash": "sha256-7gGOez8W0lF8YqIdsvMrt6lfl6mcyz9ws7tjnqMG83E=",
      "url": "_framework/Microsoft.Extensions.Primitives.q5mjvf33yv.wasm"
    },
    {
      "hash": "sha256-q3q4LRfp4kOOYx5vSM4t2vPocmWeDxNVDT9T7VeTsIs=",
      "url": "_framework/Microsoft.JSInterop.9327zjlcch.wasm"
    },
    {
      "hash": "sha256-IbbB/XtjYWT/H76RKR7XCkmdE5Vo4ubHSshoYiq9Od0=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.jnpc95ilb1.wasm"
    },
    {
      "hash": "sha256-7l0eW/QNGaUMFQddEMxXUXbxurmV4HceK8R6sqNcmUU=",
      "url": "_framework/MudBlazor.2nbsgh48li.wasm"
    },
    {
      "hash": "sha256-W8BXGbATygcEmq3PC5kBfvEOTPEE/5bcYH4jEoioi6M=",
      "url": "_framework/Plotly.Blazor.Examples.n16zrnw8q2.wasm"
    },
    {
      "hash": "sha256-OOqvFE2kGjfQvYBdr17bqbBbmlXKUlSjfYCJLEjs0iA=",
      "url": "_framework/Plotly.Blazor.o8xeytsjlo.wasm"
    },
    {
      "hash": "sha256-j1F8w2JvGXuMAicKIUwzSFWHDSR5quqcFNuEgVOoiTs=",
      "url": "_framework/System.Collections.Concurrent.h84kotvjc3.wasm"
    },
    {
      "hash": "sha256-1HGJt0nhWdMDBlXsTvUVNyxjnhOGu3QG8wd9PROS/0o=",
      "url": "_framework/System.Collections.Immutable.s62zsgq0dl.wasm"
    },
    {
      "hash": "sha256-MGmFpTkNge07Hwi13Sd3hBkoZULU643L2DeOMBvdpZw=",
      "url": "_framework/System.Collections.gowb3j2fqu.wasm"
    },
    {
      "hash": "sha256-JKTTvsOJYGxxPrp0Bfo016Od0pGkQ4K42ix8qFy8X/k=",
      "url": "_framework/System.ComponentModel.87e9suq6nz.wasm"
    },
    {
      "hash": "sha256-r7rUsjzagvvxLR11icsNVbUtGIWQtdtnOsXKo4al5QI=",
      "url": "_framework/System.ComponentModel.Primitives.xc4tuz83ax.wasm"
    },
    {
      "hash": "sha256-JOF+APdtHsqeYjBJSjieAsWDy9oQILg6+Ux5eTrvhO4=",
      "url": "_framework/System.Console.wjttc606vp.wasm"
    },
    {
      "hash": "sha256-6oyokHYVRVUEz2FZ1wnY1JVutdZ9xI8Lo+y2LjStJUo=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.2y20uwa6r3.wasm"
    },
    {
      "hash": "sha256-ybH+sm0M8AtVcGVSt7C5l6WYbkAVqPv9y8rjm7FFjH8=",
      "url": "_framework/System.IO.Pipelines.pw7nunldbe.wasm"
    },
    {
      "hash": "sha256-rVLslZGLdoTlCO7dmw0Ee3sp0kx2bDdH1SXS5QhaLCU=",
      "url": "_framework/System.Linq.Expressions.z4enangc6v.wasm"
    },
    {
      "hash": "sha256-wlYtELioY9WCnkhgLsiBRIr46wzUhWkzdgfaa8dnmjE=",
      "url": "_framework/System.Linq.uwqo7ddi7i.wasm"
    },
    {
      "hash": "sha256-IbKlP/1xEalAAq8J9ZrdSG191VdgtR+jznDCA2yua40=",
      "url": "_framework/System.Memory.tdvls1uo01.wasm"
    },
    {
      "hash": "sha256-Tsa1e0Ka1O5tj/K/cZszJa2zZpN6vqCHABh/pAjxF58=",
      "url": "_framework/System.Net.Http.uotcdijf8h.wasm"
    },
    {
      "hash": "sha256-vXxgDY1qlA3+/6lhtxS+M5g6+rQigj62PcBcKqkf+X4=",
      "url": "_framework/System.Net.Primitives.rqs3v0t645.wasm"
    },
    {
      "hash": "sha256-cguXGtl4cefGTbKBc7dxuc80UahxhbAsgLGV2DFjRG8=",
      "url": "_framework/System.ObjectModel.2b0o1jp6u6.wasm"
    },
    {
      "hash": "sha256-h0JVcjyYI/xq6RBtitYQ6TfKGjuZEtayTbg6OqVQorY=",
      "url": "_framework/System.Private.CoreLib.39gl5uagol.wasm"
    },
    {
      "hash": "sha256-XHzKKIE0OCqkSOA+slNoUxm1GnnsbnjWnIOuXF1jdVk=",
      "url": "_framework/System.Private.Uri.01k53f1wir.wasm"
    },
    {
      "hash": "sha256-ETMWUFZa1Fsc3lyns9Aa34+kGepCsHpSWhqN7e3GLeY=",
      "url": "_framework/System.Runtime.57thx947kq.wasm"
    },
    {
      "hash": "sha256-pg1DdfEus8MgtvuevXJW7tX0CHVfSV+Zu9N/Xlo6NMY=",
      "url": "_framework/System.Runtime.InteropServices.606hh9eikf.wasm"
    },
    {
      "hash": "sha256-616dBlKoT89bsUznAsXjFyNyckmQiNK3pleiln/B2Uc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.3e76cmtii9.wasm"
    },
    {
      "hash": "sha256-HOywirWXU4BVHilurwYIpsObSsXsy9DutVaAnXDHFAA=",
      "url": "_framework/System.Runtime.Serialization.Primitives.cobkw5mf49.wasm"
    },
    {
      "hash": "sha256-F8O3F97uHL3zQT4RNsDUTfe+z6kUG3ZbkFOc/la8Udg=",
      "url": "_framework/System.Security.Cryptography.1ez7qpjo6x.wasm"
    },
    {
      "hash": "sha256-Kmxa4ZQr1TJrcP30OwpaQ/q+c+VLeSmlskNQptTIu5s=",
      "url": "_framework/System.Text.Encodings.Web.ii9oypod9j.wasm"
    },
    {
      "hash": "sha256-vNMKjijLp+Se6L+ezzo3xbDXxoAMwJf7u8ieuug27Uk=",
      "url": "_framework/System.Text.Json.4wgjgkbbyp.wasm"
    },
    {
      "hash": "sha256-4W0D+GLO7HmIQDzIvWNnRjwbUafyYuFD0rpdqqhzC3A=",
      "url": "_framework/System.Text.RegularExpressions.bppwoc8sns.wasm"
    },
    {
      "hash": "sha256-JeXkfvDusZLoOt5kWMAz5dC8rQRJTwH5PMUZY3HJ80k=",
      "url": "_framework/System.Threading.jy4fgt3ud7.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-Xyuca0MBNwgUm+mWJhmZZcu2ymko0y5HYni1QoQucJY=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-RNa/XcapPytMhpPaTOGI4TBhZr8jWDGrFE3TrS6Alks=",
      "url": "_framework/dotnet.native.ksozuwxggz.js"
    },
    {
      "hash": "sha256-063AxxXcPMgBwVLXHOpyuvyEP5zLfM4fYhwPArrDk0o=",
      "url": "_framework/dotnet.native.nfufui0cas.wasm"
    },
    {
      "hash": "sha256-cajUr4vA/MpLPWj3omULUOwEQw3i8CE2n8AmDheqWBM=",
      "url": "_framework/dotnet.runtime.peu2mfb29t.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-lDAEEaul32OkTANWkZgjgs4sFCsMdLsR5NJxrjVcXdo=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SiIVMGgRhdXjKSTIddX7mh9IbOXVcwQWc7/p4nS6D/0=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-vkCWJ2ehpgCxGgxreuYgoDh7rHgZREo8v1HI2DQE5kM=",
      "url": "css/highlight/github-dark.min.css"
    },
    {
      "hash": "sha256-jA4J4h/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU/ss=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-p/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA/tb0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-tl5Gg+93b2CzSX9/vJaMWmrJHdkh4/MZNBlqJmkK7Ro=",
      "url": "index.html"
    },
    {
      "hash": "sha256-faAzXyPaEsXb9kO7m6e2ZcxDR0E4svNo9wPXEO+oagg=",
      "url": "js/highlight.min.js"
    },
    {
      "hash": "sha256-Upd0X/AAmULOTad0qMxH2hJo706AIyPvPI2ZRESJFYU=",
      "url": "js/interop.js"
    },
    {
      "hash": "sha256-mlCNbSs6jZmrgnNYKX8f3cUG0r8qGCFSfhXXGWQHbeg=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-QF7c0PDB1MZgkxy/Bb64cHNK34WuBFF/gq0NmW9h4Jo=",
      "url": "mt_bruno_elevation.csv"
    },
    {
      "hash": "sha256-jA4J4h/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU/ss=",
      "url": "open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-p/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA/tb0=",
      "url": "open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "open-iconic/font/fonts/open-iconic.woff"
    }
  ]
};
