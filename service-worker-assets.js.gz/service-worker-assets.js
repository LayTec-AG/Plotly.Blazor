self.assetsManifest = {
  "version": "HJwDHVKa",
  "assets": [
    {
      "hash": "sha256-BGK1YGP/P2sMMyzSZJSk1J959tqWV7LsQfMUWQjJF7M=",
      "url": "2011_february_aa_flight_paths.csv"
    },
    {
      "hash": "sha256-vZ54Fl+/9QN4fawzVizuo6/ZWt1LAxTtk5/yYkjT8x0=",
      "url": "Plotly.Blazor.Examples.styles.css"
    },
    {
      "hash": "sha256-ZzHmYioOIMEX9F8thiw1Sc+cGGFHLtMWI4q4uvO13CQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-zR6goaoMpR/YVMMSTfCmVNo3kuPgOkjF/ovhkUhAkbk=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-4rD3fugVb/nVJYUv5Ky3v+fYXoouHaBSP20WIJuEiWg=",
      "url": "_content/Plotly.Blazor/plotly-3.3.1.min.js"
    },
    {
      "hash": "sha256-kOt9zLVO4nC+d/IJbU54M0Vub8YeveOHv/rnSeAwhGU=",
      "url": "_content/Plotly.Blazor/plotly-basic-3.3.1.min.js"
    },
    {
      "hash": "sha256-wbh5rgVnbH+Y9LKZ+s5LKW/5iAJBaxCrKvXE2tV8cTI=",
      "url": "_content/Plotly.Blazor/plotly-interop-7.0.0.js"
    },
    {
      "hash": "sha256-i4osqcb/XQqcZngKhn/mkYkQZAcHrZ2Fld32gEnavF0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.h92wu1ed9n.wasm"
    },
    {
      "hash": "sha256-76lo69IhrCNDPSYxRIkOgGgGZvRAFduitmn99XEnMvk=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.vcqauy2dr5.wasm"
    },
    {
      "hash": "sha256-nS4uwBZEyb4DoHvEI8QCh+aJLmaRP+TDEldff98DqDo=",
      "url": "_framework/Microsoft.AspNetCore.Components.p5t0fnfiea.wasm"
    },
    {
      "hash": "sha256-wcu3iuPJejmA0aeV8AmhINoqWC8pF5jORsMjats4JrA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.jftl4iube1.wasm"
    },
    {
      "hash": "sha256-73fjp6QTz13qqhp5ePm9w7uF/0igOJntFdJ9ySeA+4c=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.5r4cx1o4hq.wasm"
    },
    {
      "hash": "sha256-YCtjvABwm5fkaWf4+QYQxWMKG6cvTym5Djrj72DM068=",
      "url": "_framework/Microsoft.Extensions.Configuration.oedzypg1by.wasm"
    },
    {
      "hash": "sha256-0WRkrf/d8sNluVTKWc1FojtSGktqCxQeuqv5+rKajlo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.9ik87pek18.wasm"
    },
    {
      "hash": "sha256-hOwEMQTCS2v3vRmeUscVJ0tbnUGR6uux9E8e0UEjd8I=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.c4qtml61yu.wasm"
    },
    {
      "hash": "sha256-5i8p7oMPBbpICOtYsTqHk+LDHxS6yLK1IOCtyKrRnc0=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.qvfmqnm3k8.wasm"
    },
    {
      "hash": "sha256-6+hWNu6IOJjQ2Q0U7rYk73IzqF8az4duNUgL24LiFUo=",
      "url": "_framework/Microsoft.Extensions.Localization.h5tijc5bhn.wasm"
    },
    {
      "hash": "sha256-nRwxel+w9GrYJpwoG5uUecjSV+zQFyc+lx64LNG8nXk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.bmc2rzh75n.wasm"
    },
    {
      "hash": "sha256-qsSxaXDaD3XGAJsq5/wE5cZZhU+/0BFEPEomwVOCNrQ=",
      "url": "_framework/Microsoft.Extensions.Logging.yhdsguskah.wasm"
    },
    {
      "hash": "sha256-oOAuzrLo1ivM+cmmg35cjklZZHg30+Grv0wFexaz9Zg=",
      "url": "_framework/Microsoft.Extensions.Options.08se1yft09.wasm"
    },
    {
      "hash": "sha256-G4XgdWPq9VnreFRqc5E+wD9aaWyvMafv1IlgAEROBW4=",
      "url": "_framework/Microsoft.Extensions.Primitives.t6jnev14u6.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-J7RvVoxnlVMjcIrzWlGs878SkQta3aAliUxj3+fEnC0=",
      "url": "_framework/Microsoft.JSInterop.bfcla62h8y.wasm"
    },
    {
      "hash": "sha256-SWXQ1khhZtOlgIt0THfQm0rYKx9JMMJhNtynAWLb0kA=",
      "url": "_framework/MudBlazor.fii8fjfko2.wasm"
    },
    {
      "hash": "sha256-XPathyYIrKdFtXLKyb/ewT1pgSpkwKLTDbYU7VuFbs0=",
      "url": "_framework/Plotly.Blazor.Examples.kmftudl2lg.wasm"
    },
    {
      "hash": "sha256-Si6m88nkmoRufL3g+uKFfoN2rO6N7c3e0qp2kGcYdZU=",
      "url": "_framework/Plotly.Blazor.yyuei2gchb.wasm"
    },
    {
      "hash": "sha256-1xo7mZFKOROxtJo1GRbMqT4kx31NY9C5JW7MbQs6Rp4=",
      "url": "_framework/System.Collections.Concurrent.lxjdbxzotw.wasm"
    },
    {
      "hash": "sha256-4XyEbpwQRz1wRHh/BEXKlXLpzVvJRf1LDLdOVbQM4kk=",
      "url": "_framework/System.Collections.Immutable.hw54i1165c.wasm"
    },
    {
      "hash": "sha256-BMBg2chfEKguOREs0xyLDJRUhNKqDbaeyJm0g1BHals=",
      "url": "_framework/System.Collections.w5v1w36018.wasm"
    },
    {
      "hash": "sha256-YGdnl0ERtqucVlT/mpHBqskIjoELs0OxPpMfWDInEH4=",
      "url": "_framework/System.ComponentModel.Primitives.s1iluzwges.wasm"
    },
    {
      "hash": "sha256-j4xVR2d1tpwZrUoag5ugeqAMDDfGXlE9q1rpeRzeLQY=",
      "url": "_framework/System.ComponentModel.zvpmoupymb.wasm"
    },
    {
      "hash": "sha256-AqpMGr2eoVlugIaSdmySAbdYMf0BemoQl2MvNSYUXTQ=",
      "url": "_framework/System.Console.6fa1v867ad.wasm"
    },
    {
      "hash": "sha256-60JunPTzXyAxbMX0wo3Mue/+PY9U9+q8ib8pkmQyqdo=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.frxchzf8l5.wasm"
    },
    {
      "hash": "sha256-UH3HJUXaHntZB5qAr8Kwhd2hYb7hh4McF4G11C92kbA=",
      "url": "_framework/System.IO.Pipelines.g0cmzdk0j7.wasm"
    },
    {
      "hash": "sha256-/XGCdyLBWu3ULInkStMjX29hOePze8pDGtOT0akDoMw=",
      "url": "_framework/System.Linq.Expressions.rq4025cpc8.wasm"
    },
    {
      "hash": "sha256-jPKJNALfVCg7V7+FQf+GHCMCClLm9Sc9DQ3sQj+Eq7w=",
      "url": "_framework/System.Linq.g7k5twk48v.wasm"
    },
    {
      "hash": "sha256-SzsaoSiOKYt/dzVzZVSS/AjmS3T06Ig3AtdJiIdZ+KQ=",
      "url": "_framework/System.Memory.rgbxbqzje6.wasm"
    },
    {
      "hash": "sha256-IJQE1CjPmRRezGz3sKQH6b0umN8sQIB84isEqKGZXLI=",
      "url": "_framework/System.Net.Http.g4svsmwp4n.wasm"
    },
    {
      "hash": "sha256-6nWJRGJPu/6h/e15f/EHoe3m0KCdPG3htdYQRocCkAo=",
      "url": "_framework/System.Net.Primitives.arovvr3kkm.wasm"
    },
    {
      "hash": "sha256-AWIY8g0aEI+i8Pb3X6a3Wai3Tm0LsXyFKSRt64y0Zoc=",
      "url": "_framework/System.ObjectModel.nefc1tdff2.wasm"
    },
    {
      "hash": "sha256-xfBR1Cpd8v1eY/nYVE0bNySlysOqteMZlegfAP4aJO0=",
      "url": "_framework/System.Private.CoreLib.5sphkw0pwj.wasm"
    },
    {
      "hash": "sha256-ikYrdt+cCMmNPIpX4V2GKAkG9qyd9K1Mc8y/NzSmQO8=",
      "url": "_framework/System.Private.Uri.yxf795lpbq.wasm"
    },
    {
      "hash": "sha256-BGnlY1Kow0vlnI3yLKWfVx+HqTgMn1PXTeg2ZLnHbD8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ottk3ocreb.wasm"
    },
    {
      "hash": "sha256-KB0TE1OfMUz076x8jL3nYYLNyocTKdVnLtN6CB5wRMk=",
      "url": "_framework/System.Runtime.InteropServices.czq9qmgm70.wasm"
    },
    {
      "hash": "sha256-VmGMDorJqvX9d2qJniNF7rcElgQ3Kkfxm/Hc69dcUdQ=",
      "url": "_framework/System.Runtime.Serialization.Primitives.y2si0o2zaf.wasm"
    },
    {
      "hash": "sha256-v8j0yvWi100acXuMEHnRJKEAg8CcwjmM4VrD6UXYG+8=",
      "url": "_framework/System.Runtime.nu7w5xtrha.wasm"
    },
    {
      "hash": "sha256-UlObAzkPDD7pdp8FJA4EPOs5u7Rre9LmYEMNz9A5Fmo=",
      "url": "_framework/System.Security.Cryptography.a5nifugrq3.wasm"
    },
    {
      "hash": "sha256-hL0r6N09lkAcPMfodof959crAsgatCOLRARJaSjHQj4=",
      "url": "_framework/System.Text.Encodings.Web.40czqnkdpt.wasm"
    },
    {
      "hash": "sha256-BsQ9tgjdCHqwtP88lFaBVSpzY1GIuqerpTt+wje3OpM=",
      "url": "_framework/System.Text.Json.2u89z1k7r1.wasm"
    },
    {
      "hash": "sha256-nTb6NVnQycMe1j3lK+QWqd50fDsWnBKzWauaNvKg49M=",
      "url": "_framework/System.Text.RegularExpressions.dwdhi5de8e.wasm"
    },
    {
      "hash": "sha256-D8d6iXjBWaqP7W4X/1UkRQeVm6l6qVYFRFSXryxaFHM=",
      "url": "_framework/System.Threading.pidygkqh4o.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-i3eMp2UY2W9bRjVliW+uqD0h5Opsm2W963l6ZSszqV0=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-7GsFpIibI8Nq0tTAKtagO9Umbg033LaYimhcZK9I6ws=",
      "url": "_framework/dotnet.native.8d1gtx6hr7.js"
    },
    {
      "hash": "sha256-rdrEzPGCSi1QTb0+Ti6KyBNEP32+Be9ox7AUCgPaH3Y=",
      "url": "_framework/dotnet.native.h7i6lhmjns.wasm"
    },
    {
      "hash": "sha256-2lZh9yO0fnzm3Xt7yV+Kox3DH3nK7L8hDhm84VT1xco=",
      "url": "_framework/dotnet.runtime.2tx45g8lli.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-lDAEEaul32OkTANWkZgjgs4sFCsMdLsR5NJxrjVcXdo=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SiIVMGgRhdXjKSTIddX7mh9IbOXVcwQWc7/p4nS6D/0=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-vkCWJ2ehpgCxGgxreuYgoDh7rHgZREo8v1HI2DQE5kM=",
      "url": "css/highlight/github-dark.min.css"
    },
    {
      "hash": "sha256-jA4J4h/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU/ss=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-p/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA/tb0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-tl5Gg+93b2CzSX9/vJaMWmrJHdkh4/MZNBlqJmkK7Ro=",
      "url": "index.html"
    },
    {
      "hash": "sha256-faAzXyPaEsXb9kO7m6e2ZcxDR0E4svNo9wPXEO+oagg=",
      "url": "js/highlight.min.js"
    },
    {
      "hash": "sha256-Upd0X/AAmULOTad0qMxH2hJo706AIyPvPI2ZRESJFYU=",
      "url": "js/interop.js"
    },
    {
      "hash": "sha256-mlCNbSs6jZmrgnNYKX8f3cUG0r8qGCFSfhXXGWQHbeg=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-QF7c0PDB1MZgkxy/Bb64cHNK34WuBFF/gq0NmW9h4Jo=",
      "url": "mt_bruno_elevation.csv"
    },
    {
      "hash": "sha256-jA4J4h/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU/ss=",
      "url": "open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-p/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA/tb0=",
      "url": "open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "open-iconic/font/fonts/open-iconic.woff"
    }
  ]
};
