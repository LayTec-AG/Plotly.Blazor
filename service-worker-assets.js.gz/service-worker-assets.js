self.assetsManifest = {
  "version": "PaghZy1T",
  "assets": [
    {
      "hash": "sha256-BGK1YGP/P2sMMyzSZJSk1J959tqWV7LsQfMUWQjJF7M=",
      "url": "2011_february_aa_flight_paths.csv"
    },
    {
      "hash": "sha256-vZ54Fl+/9QN4fawzVizuo6/ZWt1LAxTtk5/yYkjT8x0=",
      "url": "Plotly.Blazor.Examples.styles.css"
    },
    {
      "hash": "sha256-LYkXtdz4vi5vXmNqTm7rXR8RNenk5jtch4ULcWJFhKg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-RCP1u+n2DiNin+A6Edw6xsfWpI03aYyzU8pijagzeGQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-3Z7kKpQRMX82Ssav4HofwZznPVFgOXuZ2O8McYyP4Zg=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-jvTGqxNp8AGWEcvNLVuKr+8j5dGe9Yw51LQkmDH+IYA=",
      "url": "_content/Plotly.Blazor/plotly-3.7.0.min.js"
    },
    {
      "hash": "sha256-wjsDWRpr2tC9D0egxcUjBaVRmBK3POJUvmXNhBVTycI=",
      "url": "_content/Plotly.Blazor/plotly-basic-3.7.0.min.js"
    },
    {
      "hash": "sha256-Jy8hpu2KbtNrGhmn4as7OG6Uo+9LhfaGQ8GfH/LOPd0=",
      "url": "_content/Plotly.Blazor/plotly-interop-7.2.0.js"
    },
    {
      "hash": "sha256-VFlnv3DmJGQTsLM3sW8ivO3/Gc35czL/gmqWC4KDpZo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.sq16bc7sl3.wasm"
    },
    {
      "hash": "sha256-+bijrwnQfJV5Ab9bV76JCu7Zo9OIy6SAgpEoj2SyUo4=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5htjpx072c.wasm"
    },
    {
      "hash": "sha256-SATwUfNmlGScDzRQJUbTvA8/OW6YI1Cpbk9n2P/61Z8=",
      "url": "_framework/Microsoft.AspNetCore.Components.svcymgrnro.wasm"
    },
    {
      "hash": "sha256-GSuFOkP9SZd3MZN/Y0aF8cLwdFk7F0gO/LZGhJUnjj4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.1ixqznwt52.wasm"
    },
    {
      "hash": "sha256-SM9hSxJpf27xDzy5WXYeWJzeLhtMjgvykWScgZ6fI7Q=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.kdhnhqqqf3.wasm"
    },
    {
      "hash": "sha256-Qvy2yAMACsxZJK2jw9rx5KVyHUuvz5lfSS1gz55rD3Y=",
      "url": "_framework/Microsoft.Extensions.Configuration.mvtojzfkvz.wasm"
    },
    {
      "hash": "sha256-ZPg0x+4o6T6eekA8KoH1VJfMK3ORfG0QEjjOblPTwLE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.0z7ta8xr3b.wasm"
    },
    {
      "hash": "sha256-Ar+LpZ28c5wQNrN/QMR3SUC5DEXMObMnY8HlI+CaKTA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.ausc6f4kgo.wasm"
    },
    {
      "hash": "sha256-jNkEOnwwDwoX4WXK1ydXjI9PXmJ0wuO7Qbk4nUqm+pc=",
      "url": "_framework/Microsoft.Extensions.Localization.03m3bnm1u7.wasm"
    },
    {
      "hash": "sha256-13/zkZq27QMBYy2I417Ym+167HbUFY/P0ulThwxadY8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.zlw7j7fmdt.wasm"
    },
    {
      "hash": "sha256-xiI0usu822NHlFXLhxhzGQQwWK5S3dLfbu82ybsCdh4=",
      "url": "_framework/Microsoft.Extensions.Logging.21uzgcijbq.wasm"
    },
    {
      "hash": "sha256-ymabbNn22jg3dfCWV7aoVXNMzJFfutJ3X7/dKQ4KIyc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ia1d3jlnvy.wasm"
    },
    {
      "hash": "sha256-9T9uO5E1Izy9hjOwBxKSNc84/Dvy3MQ96vnFtd+UCaY=",
      "url": "_framework/Microsoft.Extensions.Options.np39dqbvuv.wasm"
    },
    {
      "hash": "sha256-5hRUqFK6QTWYDy6nLrDMpArQ1le1Zu+tXnHqejpPv4Q=",
      "url": "_framework/Microsoft.Extensions.Primitives.e3akbg9zvw.wasm"
    },
    {
      "hash": "sha256-Xcxd+z/8v1MjYI/6IsNgJ46ifV38aKmiGyz4RR+L0ms=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.5ydn64ly88.wasm"
    },
    {
      "hash": "sha256-XN1nQqdHkXtnrEoXo9noWMuRUVE6m6QnbwY6axBCMDk=",
      "url": "_framework/Microsoft.JSInterop.kicg6lwc2h.wasm"
    },
    {
      "hash": "sha256-787VpBYsQu/xOAv3PiAl+ibSYHHaZ/bmntYnh9AKKC0=",
      "url": "_framework/MudBlazor.1cuifyhyme.wasm"
    },
    {
      "hash": "sha256-zdIGNvgon3gpawjwkrfkzASBIptLiUnSakSglL1Ymtw=",
      "url": "_framework/Plotly.Blazor.91imqp7k89.wasm"
    },
    {
      "hash": "sha256-gs7dadOuHUtEhztGqP4DjP7lQE5ulbf+htUWyS/oKbU=",
      "url": "_framework/Plotly.Blazor.Examples.amqb7rwzax.wasm"
    },
    {
      "hash": "sha256-QTFKacegVeYceOZ4fvlGAonBN1aKSCmLs7SaH0komZ8=",
      "url": "_framework/System.Collections.Concurrent.5b3yswpxxg.wasm"
    },
    {
      "hash": "sha256-wnPJRszX0+BgYYV1teCP+JO/TcEaYWAcOjGFYzLtCEg=",
      "url": "_framework/System.Collections.Immutable.utpwp0j9nf.wasm"
    },
    {
      "hash": "sha256-PmK7ORtY7xc729YfjAOaxMzS7/bPBJdoP+1C0YzYbhA=",
      "url": "_framework/System.Collections.u4d7gh7rpp.wasm"
    },
    {
      "hash": "sha256-zccvq3C7kNSFinbfJXZF/0TfYLVdycqfZ8WcTNaAzyU=",
      "url": "_framework/System.ComponentModel.Primitives.vl6j8i0kpk.wasm"
    },
    {
      "hash": "sha256-FlqirVL9sIZuu5B2uysMetgDBYcJW58SWqLwNYQFKzY=",
      "url": "_framework/System.ComponentModel.e6bm8wniqf.wasm"
    },
    {
      "hash": "sha256-tJwCI9tYmBl1EY/JG2FxUDCG5QXJEypOp8v6yMWJTnw=",
      "url": "_framework/System.Console.wtocc6vx91.wasm"
    },
    {
      "hash": "sha256-0HAy02im9Ku7boVry88qJKxnDliIvz1GHXM/lJofbCQ=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0cgulbie2w.wasm"
    },
    {
      "hash": "sha256-F+momQ5WP4xfA/Vq9jEIevqHrrx2YXHsyrF9owt1h8w=",
      "url": "_framework/System.IO.Pipelines.rn8hjkm2d3.wasm"
    },
    {
      "hash": "sha256-Y5aZvVaDjxqPapFuES1NhfQd6ky0Qi1IOnWDEM2+6Pw=",
      "url": "_framework/System.Linq.Expressions.xn8728my9k.wasm"
    },
    {
      "hash": "sha256-lgDw4oOvPsU+mNWU1gbVV5HnHK7e0zoiAq09UBtQxTA=",
      "url": "_framework/System.Linq.m4znzragkk.wasm"
    },
    {
      "hash": "sha256-KGcWefSJ3N8eabMg9cWtIX/o9rSp67ep/68P4oUh8hY=",
      "url": "_framework/System.Memory.os6bs91oco.wasm"
    },
    {
      "hash": "sha256-ZzQL9Ri9UoSHOFl4l7yAHSJX0+sA3XPkbApRYvydQnM=",
      "url": "_framework/System.Net.Http.l9ko7q0p39.wasm"
    },
    {
      "hash": "sha256-KcKljuzikM+4vwo+CqRdWk+QmzHHT9E/sfyHh8sFYMg=",
      "url": "_framework/System.Net.Primitives.vu0y1pa3d8.wasm"
    },
    {
      "hash": "sha256-rPsg01iSo/hkCPfbZHInoAbW6iB525g6d7aef3BHTaM=",
      "url": "_framework/System.ObjectModel.g761y5dz5a.wasm"
    },
    {
      "hash": "sha256-zZYYkDmpbpNlDgrFLoi/KczTV2QpiyXi1Or/gSvt2K4=",
      "url": "_framework/System.Private.CoreLib.9d7q3vb291.wasm"
    },
    {
      "hash": "sha256-36MNCdsmmsxgYXNV3B0t8X/645Mp2AWYHqL7lyWmTqA=",
      "url": "_framework/System.Private.Uri.fgpkaz3glt.wasm"
    },
    {
      "hash": "sha256-b/FjBnZO8QGA5MXTmieMRuFmjH4sV++1xzkddQV58Mo=",
      "url": "_framework/System.Runtime.1smhlbk8dl.wasm"
    },
    {
      "hash": "sha256-PqykTsnB/X8Wd8ZWRG6+IlOUa+0hu2JCcbXmx9FyDII=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.6ec2lj6df3.wasm"
    },
    {
      "hash": "sha256-hRKk/mTbKOvEiiMNlxO5KeZXI1qIZfVKPN5bbnFRTUI=",
      "url": "_framework/System.Runtime.InteropServices.v3fgp5l84q.wasm"
    },
    {
      "hash": "sha256-/b4vKVf6gG2hTKtuBW4+2mLsBAdvzoGibRFP1lk1u5E=",
      "url": "_framework/System.Runtime.Serialization.Primitives.vdd9dmpzvu.wasm"
    },
    {
      "hash": "sha256-sGEUmtPJBaPdq/ek7YVIQAEJKkC/I12kno8nCPaTW7g=",
      "url": "_framework/System.Security.Cryptography.gw42xixz5p.wasm"
    },
    {
      "hash": "sha256-S/TiO9VkAEsOqdPqHjq0Z1rHDG+TMrZmL6dM5T5Nj1s=",
      "url": "_framework/System.Text.Encodings.Web.7dvilcu3lm.wasm"
    },
    {
      "hash": "sha256-PsOHV+LLyvE9KZEZf2w0rO5yeco938EJOyeo4va33jA=",
      "url": "_framework/System.Text.Json.ekqzi0wg75.wasm"
    },
    {
      "hash": "sha256-aRWsVVcMRnE5pHJZhUtqR2ElfE6xtMz2fsFZ8fvqk08=",
      "url": "_framework/System.Text.RegularExpressions.5hw053yx5o.wasm"
    },
    {
      "hash": "sha256-GB5MGCZKXmUyQ0b1e2rSIeAht3SC0h/rw63IqBuHSG4=",
      "url": "_framework/System.Threading.4xrrklpz1b.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-4LftVNmpBRgZFWPfka1P1JSh+LBdaCCxJhqNiwvyJ2Y=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-l++LgTquP6BOpUhd+sIH6zFXPHUSYOB3/ThhN6hhEmo=",
      "url": "_framework/dotnet.native.3lubk34nzn.wasm"
    },
    {
      "hash": "sha256-yM+ISK3x3pza5W686aD73juf1dKcdrQ7ZGiRoWCID40=",
      "url": "_framework/dotnet.native.kpu7hi2hy3.js"
    },
    {
      "hash": "sha256-7i3usfTrnzC/9qWO4si5Bw4w7D9fUSnSBdhQ47blX2M=",
      "url": "_framework/dotnet.runtime.a6jcqbs390.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-lDAEEaul32OkTANWkZgjgs4sFCsMdLsR5NJxrjVcXdo=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SiIVMGgRhdXjKSTIddX7mh9IbOXVcwQWc7/p4nS6D/0=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-vkCWJ2ehpgCxGgxreuYgoDh7rHgZREo8v1HI2DQE5kM=",
      "url": "css/highlight/github-dark.min.css"
    },
    {
      "hash": "sha256-jA4J4h/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU/ss=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-p/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA/tb0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-zcfVvmfZfDGPrsC+SVT+deTLYV3sawo8qmohU/QDLwQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-faAzXyPaEsXb9kO7m6e2ZcxDR0E4svNo9wPXEO+oagg=",
      "url": "js/highlight.min.js"
    },
    {
      "hash": "sha256-Upd0X/AAmULOTad0qMxH2hJo706AIyPvPI2ZRESJFYU=",
      "url": "js/interop.js"
    },
    {
      "hash": "sha256-mlCNbSs6jZmrgnNYKX8f3cUG0r8qGCFSfhXXGWQHbeg=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-QF7c0PDB1MZgkxy/Bb64cHNK34WuBFF/gq0NmW9h4Jo=",
      "url": "mt_bruno_elevation.csv"
    },
    {
      "hash": "sha256-jA4J4h/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU/ss=",
      "url": "open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-p/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA/tb0=",
      "url": "open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "open-iconic/font/fonts/open-iconic.woff"
    }
  ]
};
