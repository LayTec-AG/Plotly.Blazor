self.assetsManifest = {
  "version": "o1Jr4md9",
  "assets": [
    {
      "hash": "sha256-BGK1YGP/P2sMMyzSZJSk1J959tqWV7LsQfMUWQjJF7M=",
      "url": "2011_february_aa_flight_paths.csv"
    },
    {
      "hash": "sha256-vZ54Fl+/9QN4fawzVizuo6/ZWt1LAxTtk5/yYkjT8x0=",
      "url": "Plotly.Blazor.Examples.styles.css"
    },
    {
      "hash": "sha256-ZSJicRfSsO+B1xWmpXJ7ou81EIg418GnukAMFJRn3Bc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-EZNMO/azgG7IPa1IlFGwWmLhT64HPPCxhE0H6t+BOiM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-5BpQZYdcDdY5E4NSov7l6s03MQrl9dqLpPhfQy/lPKA=",
      "url": "_content/Plotly.Blazor/plotly-3.0.0.min.js"
    },
    {
      "hash": "sha256-xF/FXQ3buBjDFo/Wj+l9Ctt2QOOOtnbxkRCwrXWNqDI=",
      "url": "_content/Plotly.Blazor/plotly-basic-3.0.0.min.js"
    },
    {
      "hash": "sha256-RZjW9586ew2N2+PK7KgI4sXzLcCZ2mJPShUy0w5A+1E=",
      "url": "_content/Plotly.Blazor/plotly-interop-6.0.0.js"
    },
    {
      "hash": "sha256-9MVRFl9uXCA/kVnWH19jQEPWoxq4X37zthWaeNgsTcQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.cun1rfc98c.wasm"
    },
    {
      "hash": "sha256-WvE77O5BQoQEZLwZWvPTVhqUY2Z4rcQm1S1IDuxiNLQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.6xr4n5als6.wasm"
    },
    {
      "hash": "sha256-g4lNM+U4/zXod/fibsQruTENPmyhALgvvQVnkIgICzY=",
      "url": "_framework/Microsoft.AspNetCore.Components.dc4ux5hwe5.wasm"
    },
    {
      "hash": "sha256-8qmVK7yLDfc+ij+MzBcmDa9Lq52lasChCebT/C3GFzU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.y48vvcgtr7.wasm"
    },
    {
      "hash": "sha256-fpzoqR/gvd3iF1vlYLeFU7qc438hvEYOfW4e6kW7eEs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.e9vxb7i3dh.wasm"
    },
    {
      "hash": "sha256-GzBp/AqDPhBAR9yTNweNT1/JyJbwLENkGpydwfbtt8c=",
      "url": "_framework/Microsoft.Extensions.Configuration.j6zcnzlj73.wasm"
    },
    {
      "hash": "sha256-rnAtFJ1B08yRojIJa6Dypix3g7qZLZpQXgFEIqRVEkQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.et7jhwj22g.wasm"
    },
    {
      "hash": "sha256-c2tjLDSYxe2t6GkswXSeLQGmNd5vpS3z4qNSta7k1iQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pxt8fnexc7.wasm"
    },
    {
      "hash": "sha256-PpOz7kXyf12bjOdSM43X9tnPNUydfM9Ck8JHNfFdGWs=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.u929lpgn1m.wasm"
    },
    {
      "hash": "sha256-6+hWNu6IOJjQ2Q0U7rYk73IzqF8az4duNUgL24LiFUo=",
      "url": "_framework/Microsoft.Extensions.Localization.h5tijc5bhn.wasm"
    },
    {
      "hash": "sha256-It4OsLpVkPFwtpKSUhZsh2GtSwqxn4LoFLpKveHdzPw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.qed1k4wzmi.wasm"
    },
    {
      "hash": "sha256-80/De8ap0gyN55dk5uNsXFeXfErTXwOM36WyS6vbBs0=",
      "url": "_framework/Microsoft.Extensions.Logging.hnku8105c3.wasm"
    },
    {
      "hash": "sha256-ft0RPcRGOe3vG/0kzG5ECjFmWMbssCKr1oTNLgEDM0o=",
      "url": "_framework/Microsoft.Extensions.Options.yczq1rs5da.wasm"
    },
    {
      "hash": "sha256-vuHFuJFWeACDHZGepjGdhjQOkd/hdLEXNTgPvkYwOEY=",
      "url": "_framework/Microsoft.Extensions.Primitives.ysbak4uz1g.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-IE4b/bG5SH4QmpNNRREywRGntiArpSgI3Z76vDEhurQ=",
      "url": "_framework/Microsoft.JSInterop.cx70qn1k04.wasm"
    },
    {
      "hash": "sha256-UpT4klFlfmQTHHkSo3DM42q466IdYn5giL8u2Hz6VSE=",
      "url": "_framework/MudBlazor.y461jj26nz.wasm"
    },
    {
      "hash": "sha256-evA9Xg5MUoU2eZLWQ0GtgIG/uwmHniopiqeSZ6BhbaY=",
      "url": "_framework/Plotly.Blazor.61d6hmqo6m.wasm"
    },
    {
      "hash": "sha256-4HeCh6w79LriAkXdlDuPpbFDzoLtnIwkC0Cl32Dyux4=",
      "url": "_framework/Plotly.Blazor.Examples.ct04n1pkh3.wasm"
    },
    {
      "hash": "sha256-8YXFvxH7+e9xh9fi2t4iy9VIDsi0aZ4OWreZrjViaKE=",
      "url": "_framework/System.Collections.Concurrent.hocnil28gm.wasm"
    },
    {
      "hash": "sha256-rgpbwN3XX+4N7xnvkgtYleH7cqMS6w0xQyRYrWCuZSM=",
      "url": "_framework/System.Collections.Immutable.yvzonaqzv2.wasm"
    },
    {
      "hash": "sha256-rjfeMhOIuoB37tTfmDyCel6IpFb9izmTcVlsr+dwrNU=",
      "url": "_framework/System.Collections.ucqxwdc4ef.wasm"
    },
    {
      "hash": "sha256-ggftgc5cU4VTXzEcEGBVl+OtnGRGmlZ9ZZHkKMVLxYw=",
      "url": "_framework/System.ComponentModel.28u698euyz.wasm"
    },
    {
      "hash": "sha256-mFQ1/r1AZOllZEs+P1Xuj7LxqHgNCjytmL8Qk+aqDjo=",
      "url": "_framework/System.ComponentModel.Primitives.os1m6rp436.wasm"
    },
    {
      "hash": "sha256-QaRY/j3FdvZ+PJQbClV9n+A40+OL7k3TasCztjp6zR8=",
      "url": "_framework/System.Console.5bjerwp5qj.wasm"
    },
    {
      "hash": "sha256-PRXdH+yc+rku/ntBgyx5EQuHAKQP3FlrLUwSRTAubOw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.d42mh4exua.wasm"
    },
    {
      "hash": "sha256-jJ6cfHVmmYcw0lTmR2a1TgUc8C32HZDPh2cOCA21L7E=",
      "url": "_framework/System.IO.Pipelines.wv1s2h4d36.wasm"
    },
    {
      "hash": "sha256-Zh9jKGAVn/6ls23OLnsIxBcsg29Rjj9ujznmWE1+2j0=",
      "url": "_framework/System.Linq.6hf5vhiqo8.wasm"
    },
    {
      "hash": "sha256-BlEhhNghcYB8Q8ICt5u5CG9HOSvc7IBweXCrUR9oIxY=",
      "url": "_framework/System.Linq.Expressions.e6u9gkrv3q.wasm"
    },
    {
      "hash": "sha256-gPJK2eGLFjKz6TBwnpymkHmgXhsxqLRoCuMl+PUA5II=",
      "url": "_framework/System.Memory.o6tjjs1gbu.wasm"
    },
    {
      "hash": "sha256-V8EsStGhzytbZgxoJodjepiTu3seE9WrR2ATFXQn6cg=",
      "url": "_framework/System.Net.Http.z5cn44hcww.wasm"
    },
    {
      "hash": "sha256-rgmcda6lJV9MZxktdOjM0dovB8BalRKmlxpnJMiwlIE=",
      "url": "_framework/System.Net.Primitives.y79cg0kkrt.wasm"
    },
    {
      "hash": "sha256-A6j00TlOuxc/0TVMYzZ/gtB0VBkfXhvO5L9V7kRg+vQ=",
      "url": "_framework/System.ObjectModel.r2aciuuql9.wasm"
    },
    {
      "hash": "sha256-KxKWR7NVevmk+6t6Qpq+8JwvHzeNk7PwiuOpgTVyZfE=",
      "url": "_framework/System.Private.CoreLib.l0wbnk3s30.wasm"
    },
    {
      "hash": "sha256-JqoBZDAhRn9GFRypQ+5xqQ9jpbLaPb0Aybei/uXCyZw=",
      "url": "_framework/System.Private.Uri.ui0yfp0gvn.wasm"
    },
    {
      "hash": "sha256-a5MyBuzizPxYqdzmsikUBQL1f3kXFhYiFXTq5GoeZ/w=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.nh37mohxcm.wasm"
    },
    {
      "hash": "sha256-uYdCk5MR0DQHE2NsWlg+IUjgr8CJCsQgeBAJXejgTZo=",
      "url": "_framework/System.Runtime.Serialization.Primitives.d7vv0mwz9l.wasm"
    },
    {
      "hash": "sha256-zfzkeucx4Ac3Qhhk187aRqjuqjTKb6XQfuObyo+nL3o=",
      "url": "_framework/System.Runtime.to1lhwdkhn.wasm"
    },
    {
      "hash": "sha256-kOPtHz0vw909+8X/9RQPEYEgugNrJJtLRPOSSjB7cbw=",
      "url": "_framework/System.Text.Encodings.Web.oq1fx3gayd.wasm"
    },
    {
      "hash": "sha256-YUJy32+GSS5KmWWHGCz815mgMG0/BKkqWU8qy2D/6mk=",
      "url": "_framework/System.Text.Json.txm9qfn893.wasm"
    },
    {
      "hash": "sha256-c2q7wSYHKM+7Wb2yxFp1mcdNxVpv0eGTWMWHujqq9ng=",
      "url": "_framework/System.Text.RegularExpressions.1npjdgm7w4.wasm"
    },
    {
      "hash": "sha256-aIx5rnPej8hcc5oeMQsaB4zHJDz9pje2l1AYFmX3mMw=",
      "url": "_framework/System.Threading.cjrcei28ym.wasm"
    },
    {
      "hash": "sha256-dgiMrvn4ucNgqUre8avmlqyND0+fsVwaP5cEV+CyUfk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-rIXxSD3Gpo1ISvnMygpwadEB7yznILAjyYth/KW/+Qc=",
      "url": "_framework/dotnet.native.85jju0k6ws.wasm"
    },
    {
      "hash": "sha256-f5kTUT8RJErpyPQZAV7lodZzEbrbd14ZLLlmYZ1cNCw=",
      "url": "_framework/dotnet.native.hkejqzly3r.js"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-lDAEEaul32OkTANWkZgjgs4sFCsMdLsR5NJxrjVcXdo=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SiIVMGgRhdXjKSTIddX7mh9IbOXVcwQWc7/p4nS6D/0=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-vkCWJ2ehpgCxGgxreuYgoDh7rHgZREo8v1HI2DQE5kM=",
      "url": "css/highlight/github-dark.min.css"
    },
    {
      "hash": "sha256-jA4J4h/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU/ss=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-p/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA/tb0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-tl5Gg+93b2CzSX9/vJaMWmrJHdkh4/MZNBlqJmkK7Ro=",
      "url": "index.html"
    },
    {
      "hash": "sha256-faAzXyPaEsXb9kO7m6e2ZcxDR0E4svNo9wPXEO+oagg=",
      "url": "js/highlight.min.js"
    },
    {
      "hash": "sha256-Upd0X/AAmULOTad0qMxH2hJo706AIyPvPI2ZRESJFYU=",
      "url": "js/interop.js"
    },
    {
      "hash": "sha256-mlCNbSs6jZmrgnNYKX8f3cUG0r8qGCFSfhXXGWQHbeg=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-QF7c0PDB1MZgkxy/Bb64cHNK34WuBFF/gq0NmW9h4Jo=",
      "url": "mt_bruno_elevation.csv"
    },
    {
      "hash": "sha256-jA4J4h/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-aF5g/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU/ss=",
      "url": "open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-p/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA/tb0=",
      "url": "open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "open-iconic/font/fonts/open-iconic.woff"
    }
  ]
};
